package edu.cuhk.csci3310.cusweetspot;

// TODO:
// Include your personal particular here
// Name: Lo Tsz Yuk
// SID: 1155133625

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.InputStream;
import java.util.LinkedList;
import java.util.Scanner;

public class DetailActivity extends AppCompatActivity {
    private static final String TAG = "DetailActivity";

    // TODO:
    // Define other attributes as needed
    private int mGrid; // grid that user clicked
    private int mRating; // the rating after the button +/- clicked
    private EditText mSweet; // editable text of the sweet name
    private ImageView mImage; // the image of the sweet
    private TextView mLocation; // location of the restaurant
    private TextView mRate; // the rating of the sweet
    private String mSweetName;// for storing the sweet name as string to set textview
    static LinkedList<String[]> mInfoList = new LinkedList<>(); // store data get from csv
    String[] mSweetInfo = new String[10]; // store only sweet name
    String[] mRestaurantInfo = new String[10]; // store only restaurants

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Read csv
        String line;
        InputStream file = this.getResources().openRawResource(R.raw.cu_sweeties);
        Scanner scanner = new Scanner(file);

        try {
            while (scanner.hasNextLine()) {
                line = scanner.nextLine();
                String[] data = line.split(",");
                mInfoList.addLast(data);
            }
        }catch(Exception ex){
        }


        // TODO:
        // 1. Obtain data via Intent
        Intent intent = getIntent();
        try{
            mGrid = Integer.valueOf(intent.getStringExtra("grid"));
        }catch (Exception ex){
            mGrid = 0;
        }

        for(int i=0; i<10; i++) { // load information into array
            mSweetInfo[i] = mInfoList.get(mGrid+1)[1];
            mRestaurantInfo[i] = mInfoList.get(mGrid+1)[2];
        }

        // 2. Setup Views based on the data received
        mImage = (ImageView) findViewById(R.id.image_large);
        String mImagePath = MainActivity.mImagePathList.get(mGrid);
        Uri Uri= android.net.Uri.parse(mImagePath);
        mImage.setImageURI(Uri);
        mSweet = (EditText) findViewById(R.id.edit_name);
        mLocation = (TextView) findViewById(R.id.link_cu_map);
        mRate = (TextView) findViewById(R.id.value_rating);

        // 3. Setup event handler
        mLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { // create an URL then use intent to go to a website
                String restaurant_Name = mRestaurantInfo[mGrid].replace(" ","%20");
                final String openrice_URL = "https://www.openrice.com/en/hongkong/restaurants?what=";
                Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(openrice_URL +restaurant_Name));
                view.getContext().startActivity(browser);
            }
        });

        // 4. Perform necessary data-persistence steps
        SharedPreferences pref = getSharedPreferences("preference",0);
        if (pref == null){ // if nothing inside preference.xml, use default
            mRating=3;
            mSweetName = mSweetInfo[mGrid];
        }else{ // if something was set, get them
            mRating = pref.getInt("Rating"+mGrid,3); // if can't find, return default value 3
            mSweetName = pref.getString("Sweet"+mGrid,mSweetInfo[mGrid]); // if can't find, load original
        }
        mSweet.setText(mSweetName);
        mLocation.setText(mRestaurantInfo[mGrid]);
        mRate.setText(Integer.toString(mRating));
    }

    @Override
    protected void onStop() {
        super.onStop();
        // TODO:
        // Perform necessary data-persistence steps
        SharedPreferences pref=getSharedPreferences("preference", MODE_PRIVATE);
        mSweetName = String.valueOf(mSweet.getText());
        pref.edit()
            .putInt("Rating"+mGrid, mRating)
            .putString("Sweet"+mGrid, mSweetName)
            .commit();
    }

    // TODO:
    // Add more utility methods as needed
    public void minusRating(View view) {
        if (mRating >1) {
            mRating--;
            mRate.setText(Integer.toString(mRating));
        }
    }

    public void plusRating(View view) {
        if (mRating <5) {
            mRating++;
            mRate.setText(Integer.toString(mRating));
        }
    }
}