package edu.cuhk.csci3310.cusweetspot;

// TODO:
// Include your personal particular here
// Name: Lo Tsz Yuk
// SID: 1155133625

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private RecyclerView mRecyclerView;
    private SweetListAdapter mAdapter;

    // TODO:
    // Define other attributes as needed
    static LinkedList<String[]> mInfoList = new LinkedList<>();
    static LinkedList<String> mImagePathList = new LinkedList<>();
    static LinkedList<String> mSweetList = new LinkedList<>();
    static LinkedList<String> mRestaurantList = new LinkedList<>();
    private SweetListAdapter mAdapter2;
    private SweetListAdapter mAdapter3;


    //final String mRawFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/raw/";
    //final String mAppFilePath = "/data/data/edu.cuhk.csci3310.cusweetspot/";
    final String mDrawableFilePath = "android.resource://edu.cuhk.csci3310.cusweetspot/drawable/";

    // ... Rest of MainActivity code ...
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Put initial data into the image list.
        if(mImagePathList.isEmpty())
            for (int i = 1; i <= 10; i++) {
                mImagePathList.addLast(mDrawableFilePath + "image" + String.format("%02d",i));
            }

        // Get a handle to the RecyclerView.
        mRecyclerView = findViewById(R.id.recyclerview);
        // Create an adapter and supply the data to be displayed.
        // Currently only an image path list is passed

        // TODO:
        // Update and pass more information as needed
        mAdapter = new SweetListAdapter(this, mImagePathList);

        // Connect the adapter with the RecyclerView.
        mRecyclerView.setAdapter(mAdapter);

        // Give the RecyclerView a default layout manager.
        // TODO:
        // Set up Grid according to the orientation of phone
        int num_of_col=2;
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            num_of_col = 2;
        } else if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            num_of_col = 3;
        }
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, num_of_col));

    }

    // TODO:
    // Add more utility methods as needed

}
