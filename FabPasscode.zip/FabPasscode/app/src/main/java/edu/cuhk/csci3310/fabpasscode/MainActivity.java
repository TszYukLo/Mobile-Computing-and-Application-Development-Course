package edu.cuhk.csci3310.fabpasscode;

//Name: Lo Tsz Yuk
//SID: 1155133625

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // the input of the user
    private int mPasscode;
    // a checker to disable the buttons
    private int attempt = 0;
    private ImageView bird;
    private TextView mShowPasscode;
    // the correct passcode with the last 4 digits of my SID: 1155133625
    private final String correctPasscode ="3625";
    //storing the message to toast
    private String toast_message;
    private Button button0,button1,button2,button3,button4,button5,button6,button7,button8,button9,buttonUnlock;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowPasscode = findViewById(R.id.passcodeView);
        bird = findViewById(R.id.hidden_bird);
        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        buttonUnlock = findViewById((R.id.button_Unlock));
    }

    public void updatePasscode(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();
        mShowPasscode.append(buttonText);
    }

    // the function to run when unlock is clicked
    public void showToast(View view) {
        // get the number in the textview and store it as integer into mPasscode
        mPasscode = Integer.parseInt(mShowPasscode.getText().toString());
        // convert mPasscode into string for the string.contain function
        String str_mPasscode = Integer.toString(mPasscode);
        // when mPasscode contains "3625" run below
        if (str_mPasscode.contains(correctPasscode)){
            // set the toast message as Bingo to toast it later
            toast_message = "Bingo!";
            // make the image visible
            bird.setVisibility(View.VISIBLE);
            // set the checker to 1
            attempt=1;
            // make the buttons only enable when checker is equal to 0
            button0.setEnabled(attempt==0);
            button1.setEnabled(attempt==0);
            button2.setEnabled(attempt==0);
            button3.setEnabled(attempt==0);
            button4.setEnabled(attempt==0);
            button5.setEnabled(attempt==0);
            button6.setEnabled(attempt==0);
            button7.setEnabled(attempt==0);
            button8.setEnabled(attempt==0);
            button9.setEnabled(attempt==0);
            buttonUnlock.setEnabled(attempt==0);
        }else{
            // toast the incorrect passcode message when input is not correct
            toast_message = "Incorrect Passcode";
            // reset the textview and let user to guess again
            mShowPasscode.setText("");
        }
        // toast the message
        Toast toast = Toast.makeText(this, toast_message, Toast.LENGTH_SHORT);
        toast.show();
    }
}